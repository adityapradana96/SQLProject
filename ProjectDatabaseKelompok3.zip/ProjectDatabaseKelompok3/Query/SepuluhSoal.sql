--1 
SELECT StaffName, PositionName, CAST(COUNT(SalesTransactionID) AS VARCHAR) + ' Transactions' AS [Total Transaction]
FROM Staff a JOIN StaffPosition b ON a.StaffPositionID = b.StaffPositionID JOIN SalesTransaction c ON a.StaffID = c.StaffID
WHERE PositionName LIKE '%Marketing%' AND PositionGrade BETWEEN 1 AND 10
GROUP BY StaffName, PositionName

--2
SELECT a.SalesTransactionID, a.TransactionDate, b.WatchName, 'Rp. ' + CAST((b.SellingPrice * a.Quantity) AS VARCHAR) AS [Total Price]
FROM SalesTransaction a JOIN Watch b ON a.WatchID = b.WatchID
WHERE SalesTransactionID = 'SH004' AND (LEN(WatchName) > 8)

--3 
SELECT a.StaffName, b.SalesTransactionID, CONVERT (VARCHAR, b.TransactionDate, 107) AS [Transaction Date], SUM(Quantity) AS [Sales Transaction]
FROM Staff a JOIN SalesTransaction b ON a.StaffID = b.StaffID
WHERE b.Quantity > 2 AND StaffName LIKE '% %'
GROUP BY TransactionDate, StaffName, SalesTransactionID

--4 
SELECT VendorName, PurchaseTransactionID, COUNT (PurchaseTransactionID) AS [Total Transaction], 
	   CONVERT (VARCHAR, TransactionDate, 106) AS [Transaction Date]
FROM Vendor a JOIN PurchaseTransaction b ON a.VendorID = b.VendorID JOIN Watch c ON b.WatchID = c.WatchID
WHERE (PurchasePrice*Quantity) > 15000000000 AND YEAR(TransactionDate) = '2018'
GROUP BY VendorName, PurchaseTransactionID, TransactionDate

--5
SELECT 'Transaction no.' + CAST(RIGHT(SalesTransactionID,1) AS VARCHAR)  AS SalesID, StaffName, PositionName
FROM SalesTransaction a JOIN Staff b ON a.StaffID = b.StaffID JOIN StaffPosition c ON c.StaffPositionID = b.StaffPositionID, 
	(SELECT a = AVG (StaffSalary) FROM Staff) AS StaffSalaryAVG
WHERE StaffSalary > StaffSalaryAVG.a AND YEAR(StaffDOB) < '1990'

--6
SELECT StaffName, '+12' + CAST(StaffPhone AS VARCHAR) AS [Staff Phone], CONVERT (VARCHAR, TransactionDate, 100) AS [TransactionDate]
FROM Staff a JOIN PurchaseTransaction b ON a.StaffID = b.StaffID, (SELECT a = MIN (Quantity) FROM PurchaseTransaction) AS MinQuantity
WHERE b.Quantity > MinQuantity.a AND MONTH(TransactionDate) > 1

--7 
SELECT PurchaseTransactionID, LEFT(StaffName,CHARINDEX(' ',StaffName + ' ')-1) AS StaffName, SUM(Quantity) AS [Total Quantity]
FROM PurchaseTransaction a JOIN Staff b ON a.StaffID = b.StaffID JOIN Watch c ON a.WatchID = c.WatchID, (SELECT a = AVG (PurchasePrice) FROM Watch) AS AVGPurchase
WHERE PurchasePrice < AVGPurchase.a AND Quantity BETWEEN 10 AND 30
GROUP BY PurchaseTransactionID, StaffName

--8
SELECT UPPER (CustomerName) AS [Customer Name], '+62' + CAST(CustomerPhone AS VARCHAR) AS [Customer Phone], 'IDR. ' + CAST((c.SellingPrice * b.Quantity) AS VARCHAR) AS [Total Price]
FROM Customer a JOIN SalesTransaction b ON a.CustomerID = b.CustomerID JOIN Watch c ON b.WatchID = c.WatchID, (SELECT a = AVG(SellingPrice) FROM Watch) AS AVGSelling
WHERE SellingPrice > AVGSelling.a AND CustomerName LIKE '% % %'

--9 
CREATE VIEW 
CustomerQuantityViewer AS
SELECT REPLACE (a.CustomerID, 'CU', 'Customer') AS StaffID , CustomerName, CustomerEmail, MAX(b.Quantity) AS [Maximum Quantity], MIN(b.Quantity) AS [Minimum Quantity]
FROM Customer a JOIN SalesTransaction b ON a.CustomerID = b.CustomerID
WHERE CustomerGender = 'Male' AND b.Quantity > 2
GROUP BY a.CustomerID, CustomerName, CustomerEmail

SELECT * FROM CustomerQuantityViewer

--10 Masih Salah
CREATE VIEW 
[VendorPurchaseViewer] AS
SELECT v.vendorID, UPPER(VendorName) AS [Vendor Name] , [Total Purchase] = 'IDR' + CAST (SUM(PurchasePrice * Quantity) AS varchar), 
[Total Transaction] = COUNT(PurchaseTransactionID)
FROM Vendor v JOIN  PurchaseTransaction pt ON v.VendorID = pt.VendorID JOIN Watch w ON w.WatchID = pt.WatchID
GROUP BY v.VendorID, VendorName
HAVING COUNT(PurchaseTransactionID) > 1 AND SUM(PurchasePrice * Quantity) > 50000000000

SELECT * FROM VendorPurchaseViewer
