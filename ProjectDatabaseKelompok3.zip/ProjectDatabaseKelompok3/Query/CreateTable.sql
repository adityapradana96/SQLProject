CREATE DATABASE DW

CREATE TABLE StaffPosition (
				StaffPositionID CHAR (5) PRIMARY KEY NOT NULL,
				PositionName VARCHAR (30) NOT NULL,
				PositionGrade VARCHAR (50) NOT NULL,
				CONSTRAINT a CHECK (StaffPositionID LIKE 'SP[0-9][0-9][0-9]'))

SELECT * FROM StaffPosition

CREATE TABLE Staff(
	StaffID CHAR (5) PRIMARY KEY NOT NULL,
	StaffPositionID CHAR (5),
	StaffName VARCHAR (50),
	StaffGender VARCHAR (6),
	StaffEmail VARCHAR (50),
	StaffDOB DATE CHECK (DATEDIFF(YEAR,StaffDOB,GETDATE()) > 18),
	StaffPhone NUMERIC (14),
	StaffSalary NUMERIC (11,2),
	CONSTRAINT b CHECK (StaffId LIKE 'ST[0-9][0-9][0-9]'),
	CONSTRAINT c CHECK (StaffGender = 'Male' OR staffGender = 'Female'),
	CONSTRAINT d CHECK (StaffEmail LIKE '%___@___%.__%'),
	CONSTRAINT e CHECK (LEN(StaffPhone) > 8),
	FOREIGN KEY (StaffPositionID) REFERENCES StaffPosition(StaffPositionID)
)

SELECT * FROM Staff


CREATE TABLE WatchType (
	TypeID CHAR (5) PRIMARY KEY NOT NULL,
	TypeName VARCHAR (30),
	CONSTRAINT f CHECK (TypeID LIKE 'WT[0-9][0-9][0-9]')
)

SELECT * FROM WatchType

CREATE TABLE Watch(
	WatchID CHAR (5) PRIMARY KEY NOT NULL,
	WatchName VARCHAR (50),
	TypeID CHAR (5),
	SellingPrice NUMERIC (11,2),
	PurchasePrice NUMERIC (11,2),
	CONSTRAINT g CHECK (WatchID LIKE 'WH[0-9][0-9][0-9]'),
	FOREIGN KEY (TypeID) REFERENCES WatchType(TypeID)
)

SELECT * FROM Watch

CREATE TABLE Customer (
	CustomerID CHAR (5) PRIMARY KEY NOT NULL,
	CustomerName VARCHAR (50),
	CustomerPhone VARCHAR (13),
	CustomerAddress VARCHAR (50),
	CustomerGender VARCHAR (6),
	CustomerEmail VARCHAR (50),
	CONSTRAINT h CHECK (CustomerID LIKE 'CS[0-9][0-9][0-9]'),
	CONSTRAINT i CHECK (LEN(CustomerPhone) > 8),
	CONSTRAINT j CHECK (CustomerGender = 'Male' OR CustomerGender = 'Female'),
	CONSTRAINT k CHECK (CustomerEmail LIKE '%___@___%.__%'),
)

SELECT * FROM Customer

CREATE TABLE Vendor (
	VendorID CHAR (5) PRIMARY KEY NOT NULL,
	VendorName VARCHAR (50),
	VendorPhone VARCHAR (13),
	VendorAddress VARCHAR (50),
	VendorEmail VARCHAR (50),
	CONSTRAINT l CHECK (VendorID LIKE 'VN[0-9][0-9][0-9]'),
	CONSTRAINT m CHECK (LEN(VendorPhone) > 8),
	CONSTRAINT n CHECK (VendorEmail LIKE '%___@___%.__%'),
)

SELECT * FROM Vendor

CREATE TABLE SalesTransaction (
	SalesTransactionID CHAR (5) PRIMARY KEY NOT NULL,
	StaffID CHAR (5),
	CustomerID CHAR (5),
	TransactionDate DATE,
	WatchID CHAR (5),
	Quantity NUMERIC (3),
	CONSTRAINT o CHECK (SalesTransactionID LIKE 'SH[0-9][0-9][0-9]'),
	FOREIGN KEY (StaffID) REFERENCES Staff(StaffID),
	FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
	FOREIGN KEY (WatchID) REFERENCES Watch(WatchID)
)

SELECT * FROM SalesTransaction

CREATE TABLE PurchaseTransaction(
	PurchaseTransactionID CHAR (5) PRIMARY KEY NOT NULL,
	StaffID CHAR (5),
	VendorID CHAR (5),
	TransactionDate DATE,
	WatchID CHAR (5),
	Quantity NUMERIC (3),
	CONSTRAINT p CHECK (PurchaseTransactionID LIKE 'PH[0-9][0-9][0-9]'),
	FOREIGN KEY (StaffID) REFERENCES Staff(StaffID),
	FOREIGN KEY (VendorID) REFERENCES Vendor(VendorID),
	FOREIGN KEY (WatchID) REFERENCES Watch(WatchID)
)

SELECT * FROM PurchaseTransaction

CREATE TABLE DetailTransaction(
	SalesTransactionID CHAR (5),
	PurchaseTransactionID CHAR (5),
	WatchID CHAR (5),
	PRIMARY KEY (SalesTransactionID, PurchaseTransactionID, WatchID),
	FOREIGN KEY (SalesTransactionID) REFERENCES SalesTransaction(SalesTransactionID),
	FOREIGN KEY (PurchaseTransactionID) REFERENCES PurchaseTransaction(PurchaseTransactionID),
	FOREIGN KEY (WatchID) REFERENCES Watch(WatchID)
)

SELECT * FROM DetailTransaction


